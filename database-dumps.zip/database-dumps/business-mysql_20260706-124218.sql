-- MySQL dump 10.13  Distrib 8.0.45, for Linux (x86_64)
--
-- Host: localhost    Database: project_db
-- ------------------------------------------------------
-- Server version	8.0.45

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `project_db`
--

/*!40000 DROP DATABASE IF EXISTS `project_db`*/;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `project_db` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `project_db`;

--
-- Table structure for table `project_assignments`
--

DROP TABLE IF EXISTS `project_assignments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `project_assignments` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `active` bit(1) NOT NULL,
  `assigned_at` datetime(6) NOT NULL,
  `employee_id` bigint NOT NULL,
  `role` enum('DEVELOPER','MANAGER','MEMBER','QA') NOT NULL,
  `project_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_project_employee` (`project_id`,`employee_id`),
  CONSTRAINT `FKbwds7sls0j9asmsm2do8cn8co` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_assignments`
--

LOCK TABLES `project_assignments` WRITE;
/*!40000 ALTER TABLE `project_assignments` DISABLE KEYS */;
INSERT INTO `project_assignments` (`id`, `active`, `assigned_at`, `employee_id`, `role`, `project_id`) VALUES (1,_binary '','2025-10-01 08:00:00.000000',1,'MANAGER',1);
INSERT INTO `project_assignments` (`id`, `active`, `assigned_at`, `employee_id`, `role`, `project_id`) VALUES (2,_binary '','2025-10-05 08:00:00.000000',4,'DEVELOPER',1);
INSERT INTO `project_assignments` (`id`, `active`, `assigned_at`, `employee_id`, `role`, `project_id`) VALUES (3,_binary '','2025-10-05 08:00:00.000000',5,'DEVELOPER',1);
INSERT INTO `project_assignments` (`id`, `active`, `assigned_at`, `employee_id`, `role`, `project_id`) VALUES (4,_binary '','2025-10-10 08:00:00.000000',7,'DEVELOPER',1);
INSERT INTO `project_assignments` (`id`, `active`, `assigned_at`, `employee_id`, `role`, `project_id`) VALUES (5,_binary '','2025-12-01 08:00:00.000000',9,'DEVELOPER',2);
INSERT INTO `project_assignments` (`id`, `active`, `assigned_at`, `employee_id`, `role`, `project_id`) VALUES (6,_binary '','2025-10-10 08:00:00.000000',5,'QA',2);
INSERT INTO `project_assignments` (`id`, `active`, `assigned_at`, `employee_id`, `role`, `project_id`) VALUES (7,_binary '','2026-01-15 08:00:00.000000',8,'QA',2);
INSERT INTO `project_assignments` (`id`, `active`, `assigned_at`, `employee_id`, `role`, `project_id`) VALUES (8,_binary '','2025-12-01 08:00:00.000000',3,'MANAGER',3);
INSERT INTO `project_assignments` (`id`, `active`, `assigned_at`, `employee_id`, `role`, `project_id`) VALUES (9,_binary '','2025-12-05 08:00:00.000000',6,'DEVELOPER',3);
INSERT INTO `project_assignments` (`id`, `active`, `assigned_at`, `employee_id`, `role`, `project_id`) VALUES (10,_binary '','2025-12-10 08:00:00.000000',10,'MEMBER',3);
INSERT INTO `project_assignments` (`id`, `active`, `assigned_at`, `employee_id`, `role`, `project_id`) VALUES (11,_binary '','2026-01-15 08:00:00.000000',9,'MANAGER',4);
INSERT INTO `project_assignments` (`id`, `active`, `assigned_at`, `employee_id`, `role`, `project_id`) VALUES (12,_binary '','2025-11-20 08:00:00.000000',11,'MEMBER',4);
INSERT INTO `project_assignments` (`id`, `active`, `assigned_at`, `employee_id`, `role`, `project_id`) VALUES (13,_binary '','2025-12-01 08:00:00.000000',7,'QA',2);
INSERT INTO `project_assignments` (`id`, `active`, `assigned_at`, `employee_id`, `role`, `project_id`) VALUES (14,_binary '','2025-12-01 08:00:00.000000',22,'MEMBER',2);
INSERT INTO `project_assignments` (`id`, `active`, `assigned_at`, `employee_id`, `role`, `project_id`) VALUES (17,_binary '','2025-12-05 08:00:00.000000',15,'DEVELOPER',3);
INSERT INTO `project_assignments` (`id`, `active`, `assigned_at`, `employee_id`, `role`, `project_id`) VALUES (20,_binary '','2026-01-20 08:00:00.000000',15,'DEVELOPER',4);
INSERT INTO `project_assignments` (`id`, `active`, `assigned_at`, `employee_id`, `role`, `project_id`) VALUES (21,_binary '','2026-01-20 08:00:00.000000',21,'DEVELOPER',4);
INSERT INTO `project_assignments` (`id`, `active`, `assigned_at`, `employee_id`, `role`, `project_id`) VALUES (22,_binary '','2026-02-01 08:00:00.000000',23,'DEVELOPER',4);
INSERT INTO `project_assignments` (`id`, `active`, `assigned_at`, `employee_id`, `role`, `project_id`) VALUES (23,_binary '','2026-01-25 08:00:00.000000',16,'QA',4);
INSERT INTO `project_assignments` (`id`, `active`, `assigned_at`, `employee_id`, `role`, `project_id`) VALUES (24,_binary '','2026-01-20 08:00:00.000000',8,'MEMBER',4);
INSERT INTO `project_assignments` (`id`, `active`, `assigned_at`, `employee_id`, `role`, `project_id`) VALUES (25,_binary '\0','2025-08-01 08:00:00.000000',19,'MANAGER',5);
INSERT INTO `project_assignments` (`id`, `active`, `assigned_at`, `employee_id`, `role`, `project_id`) VALUES (26,_binary '\0','2025-08-05 08:00:00.000000',14,'DEVELOPER',5);
INSERT INTO `project_assignments` (`id`, `active`, `assigned_at`, `employee_id`, `role`, `project_id`) VALUES (27,_binary '\0','2025-08-05 08:00:00.000000',6,'DEVELOPER',5);
INSERT INTO `project_assignments` (`id`, `active`, `assigned_at`, `employee_id`, `role`, `project_id`) VALUES (28,_binary '\0','2025-08-10 08:00:00.000000',7,'QA',5);
INSERT INTO `project_assignments` (`id`, `active`, `assigned_at`, `employee_id`, `role`, `project_id`) VALUES (29,_binary '\0','2025-06-01 08:00:00.000000',26,'MANAGER',6);
INSERT INTO `project_assignments` (`id`, `active`, `assigned_at`, `employee_id`, `role`, `project_id`) VALUES (30,_binary '\0','2025-06-05 08:00:00.000000',11,'DEVELOPER',6);
INSERT INTO `project_assignments` (`id`, `active`, `assigned_at`, `employee_id`, `role`, `project_id`) VALUES (31,_binary '\0','2025-06-05 08:00:00.000000',17,'DEVELOPER',6);
INSERT INTO `project_assignments` (`id`, `active`, `assigned_at`, `employee_id`, `role`, `project_id`) VALUES (32,_binary '\0','2025-06-10 08:00:00.000000',5,'MEMBER',6);
INSERT INTO `project_assignments` (`id`, `active`, `assigned_at`, `employee_id`, `role`, `project_id`) VALUES (33,_binary '','2026-03-01 08:00:00.000000',25,'MANAGER',7);
INSERT INTO `project_assignments` (`id`, `active`, `assigned_at`, `employee_id`, `role`, `project_id`) VALUES (34,_binary '','2026-03-05 08:00:00.000000',14,'DEVELOPER',7);
INSERT INTO `project_assignments` (`id`, `active`, `assigned_at`, `employee_id`, `role`, `project_id`) VALUES (35,_binary '','2026-03-05 08:00:00.000000',11,'DEVELOPER',7);
INSERT INTO `project_assignments` (`id`, `active`, `assigned_at`, `employee_id`, `role`, `project_id`) VALUES (36,_binary '','2026-03-10 08:00:00.000000',22,'MEMBER',7);
INSERT INTO `project_assignments` (`id`, `active`, `assigned_at`, `employee_id`, `role`, `project_id`) VALUES (37,_binary '','2026-06-01 08:00:00.000000',27,'MANAGER',9);
INSERT INTO `project_assignments` (`id`, `active`, `assigned_at`, `employee_id`, `role`, `project_id`) VALUES (38,_binary '','2026-06-02 08:00:00.000000',2,'DEVELOPER',9);
INSERT INTO `project_assignments` (`id`, `active`, `assigned_at`, `employee_id`, `role`, `project_id`) VALUES (39,_binary '','2026-06-02 08:00:00.000000',10,'MEMBER',9);
INSERT INTO `project_assignments` (`id`, `active`, `assigned_at`, `employee_id`, `role`, `project_id`) VALUES (40,_binary '','2026-06-03 08:00:00.000000',12,'MEMBER',9);
INSERT INTO `project_assignments` (`id`, `active`, `assigned_at`, `employee_id`, `role`, `project_id`) VALUES (41,_binary '','2026-06-03 08:00:00.000000',18,'MEMBER',9);
INSERT INTO `project_assignments` (`id`, `active`, `assigned_at`, `employee_id`, `role`, `project_id`) VALUES (42,_binary '','2026-06-03 08:00:00.000000',20,'MEMBER',9);
INSERT INTO `project_assignments` (`id`, `active`, `assigned_at`, `employee_id`, `role`, `project_id`) VALUES (43,_binary '','2026-06-03 08:00:00.000000',24,'MANAGER',10);
INSERT INTO `project_assignments` (`id`, `active`, `assigned_at`, `employee_id`, `role`, `project_id`) VALUES (44,_binary '','2026-06-04 08:00:00.000000',6,'DEVELOPER',10);
INSERT INTO `project_assignments` (`id`, `active`, `assigned_at`, `employee_id`, `role`, `project_id`) VALUES (45,_binary '','2026-06-04 08:00:00.000000',7,'QA',10);
INSERT INTO `project_assignments` (`id`, `active`, `assigned_at`, `employee_id`, `role`, `project_id`) VALUES (46,_binary '','2026-06-05 08:00:00.000000',15,'DEVELOPER',10);
INSERT INTO `project_assignments` (`id`, `active`, `assigned_at`, `employee_id`, `role`, `project_id`) VALUES (47,_binary '','2026-06-05 08:00:00.000000',21,'DEVELOPER',10);
INSERT INTO `project_assignments` (`id`, `active`, `assigned_at`, `employee_id`, `role`, `project_id`) VALUES (48,_binary '','2026-06-06 08:00:00.000000',23,'DEVELOPER',10);
INSERT INTO `project_assignments` (`id`, `active`, `assigned_at`, `employee_id`, `role`, `project_id`) VALUES (49,_binary '','2026-06-06 08:00:00.000000',28,'MEMBER',10);
INSERT INTO `project_assignments` (`id`, `active`, `assigned_at`, `employee_id`, `role`, `project_id`) VALUES (50,_binary '','2026-06-05 08:00:00.000000',16,'MANAGER',11);
INSERT INTO `project_assignments` (`id`, `active`, `assigned_at`, `employee_id`, `role`, `project_id`) VALUES (51,_binary '','2026-06-06 08:00:00.000000',11,'DEVELOPER',11);
INSERT INTO `project_assignments` (`id`, `active`, `assigned_at`, `employee_id`, `role`, `project_id`) VALUES (52,_binary '','2026-06-06 08:00:00.000000',17,'DEVELOPER',11);
INSERT INTO `project_assignments` (`id`, `active`, `assigned_at`, `employee_id`, `role`, `project_id`) VALUES (53,_binary '','2026-06-07 08:00:00.000000',22,'MEMBER',11);
INSERT INTO `project_assignments` (`id`, `active`, `assigned_at`, `employee_id`, `role`, `project_id`) VALUES (54,_binary '','2026-06-07 08:00:00.000000',25,'MEMBER',11);
INSERT INTO `project_assignments` (`id`, `active`, `assigned_at`, `employee_id`, `role`, `project_id`) VALUES (55,_binary '','2026-06-07 08:00:00.000000',26,'MEMBER',11);
INSERT INTO `project_assignments` (`id`, `active`, `assigned_at`, `employee_id`, `role`, `project_id`) VALUES (56,_binary '','2026-06-07 08:00:00.000000',25,'MANAGER',12);
INSERT INTO `project_assignments` (`id`, `active`, `assigned_at`, `employee_id`, `role`, `project_id`) VALUES (57,_binary '','2026-06-08 08:00:00.000000',14,'DEVELOPER',12);
INSERT INTO `project_assignments` (`id`, `active`, `assigned_at`, `employee_id`, `role`, `project_id`) VALUES (58,_binary '','2026-06-08 08:00:00.000000',19,'MEMBER',12);
INSERT INTO `project_assignments` (`id`, `active`, `assigned_at`, `employee_id`, `role`, `project_id`) VALUES (59,_binary '','2026-06-08 08:00:00.000000',1,'MEMBER',12);
INSERT INTO `project_assignments` (`id`, `active`, `assigned_at`, `employee_id`, `role`, `project_id`) VALUES (60,_binary '','2026-06-09 08:00:00.000000',3,'MEMBER',12);
INSERT INTO `project_assignments` (`id`, `active`, `assigned_at`, `employee_id`, `role`, `project_id`) VALUES (61,_binary '','2026-06-09 08:00:00.000000',4,'MEMBER',12);
INSERT INTO `project_assignments` (`id`, `active`, `assigned_at`, `employee_id`, `role`, `project_id`) VALUES (62,_binary '','2026-06-09 08:00:00.000000',5,'MEMBER',12);
INSERT INTO `project_assignments` (`id`, `active`, `assigned_at`, `employee_id`, `role`, `project_id`) VALUES (63,_binary '','2026-06-10 08:00:00.000000',8,'MEMBER',12);
INSERT INTO `project_assignments` (`id`, `active`, `assigned_at`, `employee_id`, `role`, `project_id`) VALUES (64,_binary '','2026-06-10 08:00:00.000000',9,'MEMBER',12);
/*!40000 ALTER TABLE `project_assignments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projects`
--

DROP TABLE IF EXISTS `projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `projects` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) NOT NULL,
  `description` text,
  `lead_id` bigint NOT NULL,
  `name` varchar(255) NOT NULL,
  `status` enum('ACTIVE','ARCHIVED','COMPLETED','PAUSED') NOT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projects`
--

LOCK TABLES `projects` WRITE;
/*!40000 ALTER TABLE `projects` DISABLE KEYS */;
INSERT INTO `projects` (`id`, `created_at`, `description`, `lead_id`, `name`, `status`, `updated_at`) VALUES (1,'2026-06-05 17:09:04.901198','NÃ¢ng cáº¥p toÃ n diá»‡n ná»n táº£ng quáº£n lÃ½ nhÃ¢n sá»±: employee lifecycle, phÃ¢n quyá»n RBAC, API chuáº©n hoÃ¡. LÃ  dá»± Ã¡n ná»n táº£ng cho toÃ n há»‡ thá»‘ng ECC.',3,'ECC HR Platform v2.0','ACTIVE','2026-07-06 05:41:00.981906');
INSERT INTO `projects` (`id`, `created_at`, `description`, `lead_id`, `name`, `status`, `updated_at`) VALUES (2,'2026-06-06 04:26:12.440478','Tá»± Ä‘á»™ng hoÃ¡ quy trÃ¬nh tÃ­nh lÆ°Æ¡ng, quáº£n lÃ½ kháº¥u trá»« BHXH/BHYT/BHTN, thuáº¿ TNCN luá»¹ tiáº¿n, phÃª duyá»‡t báº£ng lÆ°Æ¡ng Ä‘a cáº¥p vÃ  xuáº¥t bÃ¡o cÃ¡o quyáº¿t toÃ¡n.',9,'Payroll Automation System','ACTIVE','2026-07-06 05:41:00.981906');
INSERT INTO `projects` (`id`, `created_at`, `description`, `lead_id`, `name`, `status`, `updated_at`) VALUES (3,'2026-06-06 04:26:12.440478','Cá»•ng tá»± phá»¥c vá»¥ dÃ nh cho nhÃ¢n viÃªn: xem há»£p Ä‘á»“ng, phiáº¿u lÆ°Æ¡ng, yÃªu cáº§u nghá»‰ phÃ©p, cáº­p nháº­t thÃ´ng tin cÃ¡ nhÃ¢n vÃ  theo dÃµi KPI.',3,'Employee Self-Service Portal','PAUSED','2026-07-06 05:41:00.981906');
INSERT INTO `projects` (`id`, `created_at`, `description`, `lead_id`, `name`, `status`, `updated_at`) VALUES (4,'2026-06-06 04:26:12.440478','á»¨ng dá»¥ng di Ä‘á»™ng (iOS/Android) cho quáº£n lÃ½ dá»± Ã¡n vÃ  task theo thá»i gian thá»±c, thÃ´ng bÃ¡o push, check-in Ä‘á»‹a Ä‘iá»ƒm vÃ  bÃ¡o cÃ¡o nhanh.',9,'ECC Mobile App','ACTIVE','2026-07-06 05:41:00.981906');
INSERT INTO `projects` (`id`, `created_at`, `description`, `lead_id`, `name`, `status`, `updated_at`) VALUES (5,'2025-08-01 08:00:00.000000','TÃ­ch há»£p há»‡ thá»‘ng CRM ná»™i bá»™ vá»›i Salesforce: Ä‘á»“ng bá»™ khÃ¡ch hÃ ng, cÆ¡ há»™i kinh doanh, lá»‹ch sá»­ tÆ°Æ¡ng tÃ¡c vÃ  bÃ¡o cÃ¡o doanh sá»‘ tá»± Ä‘á»™ng.',19,'CRM Integration','COMPLETED','2026-07-06 05:41:00.981906');
INSERT INTO `projects` (`id`, `created_at`, `description`, `lead_id`, `name`, `status`, `updated_at`) VALUES (6,'2025-06-01 08:00:00.000000','Di chuyá»ƒn toÃ n bá»™ háº¡ táº§ng on-premise sang AWS (EKS + RDS + S3 + CloudFront). Bao gá»“m CI/CD pipeline, blue-green deployment vÃ  disaster recovery.',26,'Cloud Infrastructure Migration','COMPLETED','2026-07-06 05:41:00.981906');
INSERT INTO `projects` (`id`, `created_at`, `description`, `lead_id`, `name`, `status`, `updated_at`) VALUES (7,'2026-03-01 08:00:00.000000','XÃ¢y dá»±ng há»‡ thá»‘ng phÃ¢n tÃ­ch dá»¯ liá»‡u nhÃ¢n sá»± vÃ  kinh doanh vá»›i Grafana, Metabase vÃ  pipeline ETL tá»« MySQL/PostgreSQL sang Data Warehouse.',25,'Data Analytics Dashboard','ACTIVE','2026-07-06 05:41:00.981906');
INSERT INTO `projects` (`id`, `created_at`, `description`, `lead_id`, `name`, `status`, `updated_at`) VALUES (9,'2026-06-01 08:00:00.000000','Hop nhat quy trinh noi bo: onboarding, yeu cau noi bo, asset tracking va bao cao van hanh.',27,'Internal Operations Hub','ACTIVE','2026-07-05 08:18:04.203519');
INSERT INTO `projects` (`id`, `created_at`, `description`, `lead_id`, `name`, `status`, `updated_at`) VALUES (10,'2026-06-03 08:00:00.000000','Mo rong nang luc ho tro khach hang: knowledge base, SLA, ticket routing va bao cao chat luong.',24,'Customer Support Scale-up','ACTIVE','2026-07-05 08:18:04.203519');
INSERT INTO `projects` (`id`, `created_at`, `description`, `lead_id`, `name`, `status`, `updated_at`) VALUES (11,'2026-06-05 08:00:00.000000','Tang cuong an toan he thong: secrets rotation, audit log, dependency scan va incident playbook.',16,'Security and Compliance Hardening','ACTIVE','2026-07-05 08:18:04.203519');
INSERT INTO `projects` (`id`, `created_at`, `description`, `lead_id`, `name`, `status`, `updated_at`) VALUES (12,'2026-06-07 08:00:00.000000','Tong hop so lieu nhan su, project va task vao bo bao cao quan tri cho ban lanh dao.',25,'Data and Reporting Hub','ACTIVE','2026-07-05 08:18:04.203519');
/*!40000 ALTER TABLE `projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'project_db'
--

--
-- Current Database: `task_db`
--

/*!40000 DROP DATABASE IF EXISTS `task_db`*/;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `task_db` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `task_db`;

--
-- Table structure for table `automation_rules`
--

DROP TABLE IF EXISTS `automation_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `automation_rules` (
  `rule_id` varchar(100) NOT NULL,
  `action_channel` varchar(50) DEFAULT NULL,
  `action_target_status` varchar(50) DEFAULT NULL,
  `action_type` varchar(100) NOT NULL,
  `is_enabled` bit(1) NOT NULL,
  `rule_name` varchar(255) NOT NULL,
  `trigger_condition` varchar(100) NOT NULL,
  `trigger_event` varchar(100) NOT NULL,
  PRIMARY KEY (`rule_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `automation_rules`
--

LOCK TABLES `automation_rules` WRITE;
/*!40000 ALTER TABLE `automation_rules` DISABLE KEYS */;
/*!40000 ALTER TABLE `automation_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `task_history`
--

DROP TABLE IF EXISTS `task_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `task_history` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `changed_at` datetime(6) NOT NULL,
  `changed_by` bigint DEFAULT NULL,
  `new_status` varchar(255) DEFAULT NULL,
  `previous_status` varchar(255) DEFAULT NULL,
  `project_id` bigint DEFAULT NULL,
  `reason` text,
  `task_id` bigint NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `task_history`
--

LOCK TABLES `task_history` WRITE;
/*!40000 ALTER TABLE `task_history` DISABLE KEYS */;
INSERT INTO `task_history` (`id`, `changed_at`, `changed_by`, `new_status`, `previous_status`, `project_id`, `reason`, `task_id`) VALUES (1,'2025-10-06 08:30:00.000000',14,'IN_PROGRESS','OPEN',1,'Báº¯t Ä‘áº§u thiáº¿t káº¿ API spec trÃªn Swagger Editor',1);
INSERT INTO `task_history` (`id`, `changed_at`, `changed_by`, `new_status`, `previous_status`, `project_id`, `reason`, `task_id`) VALUES (2,'2025-11-20 16:00:00.000000',3,'COMPLETED','IN_PROGRESS',1,'API spec Ä‘Ã£ review vÃ  Ä‘Æ°á»£c PM approve, merge vÃ o main',1);
INSERT INTO `task_history` (`id`, `changed_at`, `changed_by`, `new_status`, `previous_status`, `project_id`, `reason`, `task_id`) VALUES (3,'2025-10-12 08:00:00.000000',4,'IN_PROGRESS','OPEN',1,'Báº¯t Ä‘áº§u code DepartmentController vÃ  service layer',2);
INSERT INTO `task_history` (`id`, `changed_at`, `changed_by`, `new_status`, `previous_status`, `project_id`, `reason`, `task_id`) VALUES (4,'2025-12-10 15:00:00.000000',4,'COMPLETED','IN_PROGRESS',1,'ÄÃ£ pass háº¿t unit test vÃ  integration test, deploy staging',2);
INSERT INTO `task_history` (`id`, `changed_at`, `changed_by`, `new_status`, `previous_status`, `project_id`, `reason`, `task_id`) VALUES (5,'2025-11-05 09:00:00.000000',5,'IN_PROGRESS','OPEN',1,'Báº¯t Ä‘áº§u implement JWT claims middleware táº¡i api-gateway',3);
INSERT INTO `task_history` (`id`, `changed_at`, `changed_by`, `new_status`, `previous_status`, `project_id`, `reason`, `task_id`) VALUES (6,'2025-11-18 08:00:00.000000',9,'IN_PROGRESS','OPEN',2,'Báº¯t Ä‘áº§u váº½ flowchart vÃ  Ä‘á»‹nh nghÄ©a state machine lÆ°Æ¡ng',9);
INSERT INTO `task_history` (`id`, `changed_at`, `changed_by`, `new_status`, `previous_status`, `project_id`, `reason`, `task_id`) VALUES (7,'2025-12-20 14:00:00.000000',27,'COMPLETED','IN_PROGRESS',2,'TÃ i liá»‡u quy trÃ¬nh Ä‘Æ°á»£c HR Director duyá»‡t vÃ  kÃ½',9);
INSERT INTO `task_history` (`id`, `changed_at`, `changed_by`, `new_status`, `previous_status`, `project_id`, `reason`, `task_id`) VALUES (8,'2025-11-22 08:00:00.000000',13,'IN_PROGRESS','OPEN',2,'Báº¯t Ä‘áº§u implement thuáº¿ luá»¹ tiáº¿n tá»« TaxConfig table',10);
INSERT INTO `task_history` (`id`, `changed_at`, `changed_by`, `new_status`, `previous_status`, `project_id`, `reason`, `task_id`) VALUES (9,'2026-01-15 16:00:00.000000',13,'COMPLETED','IN_PROGRESS',2,'ÄÃ£ test 150 test case, coverage 98%. Deploy production',10);
INSERT INTO `task_history` (`id`, `changed_at`, `changed_by`, `new_status`, `previous_status`, `project_id`, `reason`, `task_id`) VALUES (10,'2025-12-03 09:00:00.000000',8,'IN_PROGRESS','OPEN',3,'Báº¯t Ä‘áº§u thiáº¿t káº¿ wireframe Figma, há»p kick-off vá»›i HR',17);
INSERT INTO `task_history` (`id`, `changed_at`, `changed_by`, `new_status`, `previous_status`, `project_id`, `reason`, `task_id`) VALUES (11,'2026-01-10 16:00:00.000000',8,'COMPLETED','IN_PROGRESS',3,'Figma prototype Ä‘Æ°á»£c approve, link shared vá»›i dev team',17);
INSERT INTO `task_history` (`id`, `changed_at`, `changed_by`, `new_status`, `previous_status`, `project_id`, `reason`, `task_id`) VALUES (12,'2026-01-17 09:00:00.000000',9,'IN_PROGRESS','OPEN',4,'Há»p kiáº¿n trÃºc, báº¯t Ä‘áº§u POC React Native + Expo',23);
INSERT INTO `task_history` (`id`, `changed_at`, `changed_by`, `new_status`, `previous_status`, `project_id`, `reason`, `task_id`) VALUES (13,'2026-02-10 16:00:00.000000',9,'COMPLETED','IN_PROGRESS',4,'POC xong, team Ä‘á»“ng thuáº­n tech stack, táº¡o repo',23);
INSERT INTO `task_history` (`id`, `changed_at`, `changed_by`, `new_status`, `previous_status`, `project_id`, `reason`, `task_id`) VALUES (14,'2026-01-22 09:00:00.000000',15,'IN_PROGRESS','OPEN',4,'Implement OAuth2 flow vÃ  TOTP 2FA trÃªn React Native',24);
INSERT INTO `task_history` (`id`, `changed_at`, `changed_by`, `new_status`, `previous_status`, `project_id`, `reason`, `task_id`) VALUES (15,'2026-03-15 15:00:00.000000',16,'COMPLETED','IN_PROGRESS',4,'Login flow test OK trÃªn iOS vÃ  Android, biometric hoáº¡t Ä‘á»™ng',24);
INSERT INTO `task_history` (`id`, `changed_at`, `changed_by`, `new_status`, `previous_status`, `project_id`, `reason`, `task_id`) VALUES (16,'2025-08-05 09:00:00.000000',19,'IN_PROGRESS','OPEN',5,'Báº¯t Ä‘áº§u workshop vÃ  thu tháº­p yÃªu cáº§u tá»« sales team',31);
INSERT INTO `task_history` (`id`, `changed_at`, `changed_by`, `new_status`, `previous_status`, `project_id`, `reason`, `task_id`) VALUES (17,'2025-08-31 16:00:00.000000',19,'COMPLETED','IN_PROGRESS',5,'HoÃ n thÃ nh tÃ i liá»‡u BRD vÃ  mapping schema CRM â†” ECC',31);
INSERT INTO `task_history` (`id`, `changed_at`, `changed_by`, `new_status`, `previous_status`, `project_id`, `reason`, `task_id`) VALUES (18,'2025-06-05 08:00:00.000000',26,'IN_PROGRESS','OPEN',6,'Báº¯t Ä‘áº§u phÃ¢n tÃ­ch workload vÃ  thiáº¿t káº¿ VPC architecture',37);
INSERT INTO `task_history` (`id`, `changed_at`, `changed_by`, `new_status`, `previous_status`, `project_id`, `reason`, `task_id`) VALUES (19,'2025-07-31 16:00:00.000000',1,'COMPLETED','IN_PROGRESS',6,'AWS Well-Architected Review pass, approved by CTO',37);
INSERT INTO `task_history` (`id`, `changed_at`, `changed_by`, `new_status`, `previous_status`, `project_id`, `reason`, `task_id`) VALUES (20,'2026-03-05 09:00:00.000000',25,'IN_PROGRESS','OPEN',7,'Báº¯t Ä‘áº§u thiáº¿t káº¿ star schema, há»p vá»›i stakeholders',43);
INSERT INTO `task_history` (`id`, `changed_at`, `changed_by`, `new_status`, `previous_status`, `project_id`, `reason`, `task_id`) VALUES (21,'2026-04-15 15:00:00.000000',25,'COMPLETED','IN_PROGRESS',7,'Schema Ä‘Ã£ review vÃ  approve, dbt models táº¡o xong',43);
INSERT INTO `task_history` (`id`, `changed_at`, `changed_by`, `new_status`, `previous_status`, `project_id`, `reason`, `task_id`) VALUES (22,'2026-03-18 09:00:00.000000',14,'IN_PROGRESS','OPEN',7,'Setup Airflow DAG, báº¯t Ä‘áº§u viáº¿t dbt models cho HR data',44);
INSERT INTO `task_history` (`id`, `changed_at`, `changed_by`, `new_status`, `previous_status`, `project_id`, `reason`, `task_id`) VALUES (23,'2026-06-02 10:00:00.000000',27,'IN_PROGRESS','OPEN',9,'Kick-off quy trinh noi bo',50);
INSERT INTO `task_history` (`id`, `changed_at`, `changed_by`, `new_status`, `previous_status`, `project_id`, `reason`, `task_id`) VALUES (24,'2026-06-04 16:00:00.000000',12,'COMPLETED','IN_PROGRESS',9,'Lich hop da duoc cap nhat va chot lich',54);
INSERT INTO `task_history` (`id`, `changed_at`, `changed_by`, `new_status`, `previous_status`, `project_id`, `reason`, `task_id`) VALUES (25,'2026-06-04 10:00:00.000000',24,'IN_PROGRESS','OPEN',10,'Bat dau xay dung knowledge base',55);
INSERT INTO `task_history` (`id`, `changed_at`, `changed_by`, `new_status`, `previous_status`, `project_id`, `reason`, `task_id`) VALUES (26,'2026-06-04 11:00:00.000000',6,'IN_PROGRESS','OPEN',10,'Da co mockup dashboard support',56);
INSERT INTO `task_history` (`id`, `changed_at`, `changed_by`, `new_status`, `previous_status`, `project_id`, `reason`, `task_id`) VALUES (27,'2026-06-05 10:00:00.000000',11,'IN_PROGRESS','OPEN',11,'Bat dau xay dung luong xoay secrets',62);
INSERT INTO `task_history` (`id`, `changed_at`, `changed_by`, `new_status`, `previous_status`, `project_id`, `reason`, `task_id`) VALUES (28,'2026-06-07 15:00:00.000000',26,'COMPLETED','OPEN',11,'Policy scan da duoc phe duyet',67);
INSERT INTO `task_history` (`id`, `changed_at`, `changed_by`, `new_status`, `previous_status`, `project_id`, `reason`, `task_id`) VALUES (29,'2026-06-08 09:30:00.000000',25,'IN_PROGRESS','OPEN',12,'Dashboard KPI da duoc khoi dong',68);
INSERT INTO `task_history` (`id`, `changed_at`, `changed_by`, `new_status`, `previous_status`, `project_id`, `reason`, `task_id`) VALUES (30,'2026-06-09 10:00:00.000000',3,'IN_PROGRESS','OPEN',12,'Bat dau tinh toan allocation report',72);
INSERT INTO `task_history` (`id`, `changed_at`, `changed_by`, `new_status`, `previous_status`, `project_id`, `reason`, `task_id`) VALUES (31,'2026-06-10 09:30:00.000000',9,'IN_PROGRESS','OPEN',12,'Ban lanh dao yeu cau ban tom tat thang',76);
INSERT INTO `task_history` (`id`, `changed_at`, `changed_by`, `new_status`, `previous_status`, `project_id`, `reason`, `task_id`) VALUES (32,'2026-06-08 12:00:00.000000',1,'IN_PROGRESS','OPEN',12,'Lam sach KPI data truoc khi import',71);
/*!40000 ALTER TABLE `task_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tasks`
--

DROP TABLE IF EXISTS `tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tasks` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `assignee_id` bigint NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `description` text,
  `project_id` bigint NOT NULL,
  `status` enum('CANCELLED','COMPLETED','IN_PROGRESS','OPEN') NOT NULL,
  `priority` enum('HIGH','LOW','MEDIUM','URGENT') NOT NULL,
  `title` varchar(255) NOT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tasks`
--

LOCK TABLES `tasks` WRITE;
/*!40000 ALTER TABLE `tasks` DISABLE KEYS */;
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (1,14,'2026-06-05 17:09:07.018321','Äá»‹nh nghÄ©a OpenAPI 3.0 cho toÃ n bá»™ endpoint nhÃ¢n viÃªn: táº¡o, cáº­p nháº­t, xem danh sÃ¡ch, vÃ´ hiá»‡u hoÃ¡. Bao gá»“m phÃ¢n trang vÃ  filter.',1,'COMPLETED','HIGH','Thiáº¿t káº¿ API employee CRUD','2026-07-06 05:41:01.195885');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (2,4,'2026-06-06 04:26:43.328918','REST endpoint cho phÃ²ng ban: táº¡o, chá»‰nh sá»­a, xem cÃ¢y tá»• chá»©c theo organization_unit. Validate unique department code.',1,'COMPLETED','HIGH','XÃ¢y dá»±ng Department API & phÃ¢n cáº¥p','2026-07-06 05:41:01.195885');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (3,5,'2026-06-06 04:26:43.328918','ThÃªm JWT claims check vÃ  middleware kiá»ƒm tra quyá»n RBAC (READ_EMPLOYEE, WRITE_EMPLOYEE...) táº¡i api-gateway trÆ°á»›c khi chuyá»ƒn tiáº¿p request.',1,'IN_PROGRESS','URGENT','TÃ­ch há»£p RBAC vÃ o API Gateway','2026-07-06 05:41:01.195885');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (4,21,'2026-06-06 04:26:43.328918','Trang danh sÃ¡ch nhÃ¢n viÃªn vá»›i bá»™ lá»c (phÃ²ng ban, chá»©c vá»¥, tráº¡ng thÃ¡i), phÃ¢n trang, export Excel. DÃ¹ng DataListPage component.',1,'IN_PROGRESS','HIGH','XÃ¢y dá»±ng Employee List UI','2026-07-06 05:41:01.195885');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (5,7,'2026-06-06 04:26:43.328918','Test Playwright cho toÃ n bá»™ luá»“ng thÃªm nhÃ¢n viÃªn má»›i: táº¡o user Auth â†’ táº¡o Employee HR â†’ gÃ¡n phÃ²ng ban â†’ kiá»ƒm tra hiá»ƒn thá»‹ dashboard.',1,'OPEN','HIGH','Viáº¿t test E2E cho luá»“ng onboarding','2026-07-06 05:41:01.195885');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (6,14,'2026-06-06 04:26:43.328918','PhÃ¢n tÃ­ch slow query log: thÃªm index (department_id, status, hire_date), chuyá»ƒn N+1 sang JOIN, cache Redis cho danh sÃ¡ch phÃ²ng ban.',1,'OPEN','MEDIUM','Tá»‘i Æ°u truy váº¥n Employee + Department','2026-07-06 05:41:01.195885');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (7,8,'2026-06-06 04:26:43.328918','Bá»• sung mÃ´ táº£ tiáº¿ng Viá»‡t, vÃ­ dá»¥ request/response, mÃ£ lá»—i cho táº¥t cáº£ endpoint HR. Deploy Swagger UI lÃªn /api-docs.',1,'OPEN','LOW','Cáº­p nháº­t tÃ i liá»‡u API (Swagger)','2026-07-06 05:41:01.195885');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (8,16,'2026-06-06 04:26:43.328918','Kiá»ƒm tra SQL injection, XSS header, rate limit, validate input táº¥t cáº£ endpoint /nhan-vien vÃ  /phong-ban. BÃ¡o cÃ¡o penetration test.',1,'OPEN','URGENT','Review báº£o máº­t endpoint nhÃ¢n sá»±','2026-07-06 05:41:01.195885');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (9,9,'2026-06-06 04:26:43.328918','SÆ¡ Ä‘á»“ luá»“ng: DRAFT â†’ APPROVED (Payroll Officer) â†’ PROCESSED (HR Manager) â†’ PAID. Äá»‹nh nghÄ©a rule & permission tá»«ng bÆ°á»›c.',2,'COMPLETED','HIGH','Thiáº¿t káº¿ quy trÃ¬nh duyá»‡t lÆ°Æ¡ng Ä‘a cáº¥p','2026-07-06 05:41:01.195885');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (10,13,'2026-06-06 04:26:43.328918','TÃ­nh thuáº¿ luá»¹ tiáº¿n VN 2024 tá»« TaxConfig. Trá»« giáº£m trá»« báº£n thÃ¢n (11tr), gia cáº£nh (4.4tr/ngÆ°á»i), BHXH trÆ°á»›c khi tÃ­nh thuáº¿.',2,'COMPLETED','URGENT','Implement engine tÃ­nh thuáº¿ TNCN','2026-07-06 05:41:01.195885');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (11,4,'2026-06-06 04:26:43.328918','Trang xem báº£ng lÆ°Æ¡ng theo ká»³: lá»c theo tráº¡ng thÃ¡i, táº£i PDF phiáº¿u lÆ°Æ¡ng cÃ¡ nhÃ¢n, tá»•ng káº¿t theo phÃ²ng ban.',2,'IN_PROGRESS','HIGH','Giao diá»‡n báº£ng lÆ°Æ¡ng (Payroll UI)','2026-07-06 05:41:01.195885');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (12,28,'2026-06-06 04:26:43.328918','Táº¡o file Excel/PDF bÃ¡o cÃ¡o quyáº¿t toÃ¡n thuáº¿ hÃ ng thÃ¡ng & nÄƒm theo máº«u quy Ä‘á»‹nh, bao gá»“m tá»•ng há»£p BHXH doanh nghiá»‡p.',2,'IN_PROGRESS','HIGH','Xuáº¥t bÃ¡o cÃ¡o quyáº¿t toÃ¡n thuáº¿','2026-07-06 05:41:01.195885');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (13,7,'2026-06-06 04:26:43.328918','Táº¡o 100+ test case tÃ­nh lÆ°Æ¡ng: lÆ°Æ¡ng cÆ¡ báº£n, thÆ°á»Ÿng, phá»¥ cáº¥p, lÃ m thÃªm giá», nghá»‰ phÃ©p, nghá»‰ khÃ´ng lÆ°Æ¡ng, á»‘m Ä‘au...',2,'OPEN','URGENT','Kiá»ƒm thá»­ tÃ­nh lÆ°Æ¡ng tá»± Ä‘á»™ng (100+ TH)','2026-07-06 05:41:01.195885');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (14,22,'2026-06-06 04:26:43.328918','Gá»­i email tá»± Ä‘á»™ng khi báº£ng lÆ°Æ¡ng chuyá»ƒn tráº¡ng thÃ¡i (APPROVED, PROCESSED). DÃ¹ng RabbitMQ message queue, template HTML.',2,'OPEN','MEDIUM','TÃ­ch há»£p thÃ´ng bÃ¡o duyá»‡t lÆ°Æ¡ng qua email','2026-07-06 05:41:01.195885');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (15,13,'2026-06-12 02:27:28.015943','Endpoint /api/payroll/{id}/export-pdf táº¡o phiáº¿u lÆ°Æ¡ng cÃ¡ nhÃ¢n Ä‘á»‹nh dáº¡ng A4, kÃ½ sá»‘ Ä‘iá»‡n tá»­, táº£i xuá»‘ng hoáº·c gá»­i email.',2,'OPEN','MEDIUM','API export phiáº¿u lÆ°Æ¡ng PDF','2026-07-06 05:41:01.195885');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (16,28,'2026-03-15 08:00:00.000000','Ghi PayrollHistory má»—i khi báº£ng lÆ°Æ¡ng thay Ä‘á»•i tráº¡ng thÃ¡i. Hiá»ƒn thá»‹ timeline audit trÃªn UI. Export CSV cho kiá»ƒm toÃ¡n.',2,'OPEN','LOW','LÆ°u lá»‹ch sá»­ thay Ä‘á»•i lÆ°Æ¡ng (audit)','2026-07-06 05:41:01.195885');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (17,8,'2025-12-01 08:00:00.000000','Figma wireframe cho táº¥t cáº£ mÃ n hÃ¬nh portal: trang chá»§, xem lÆ°Æ¡ng, yÃªu cáº§u nghá»‰ phÃ©p, cáº­p nháº­t thÃ´ng tin, tra cá»©u ná»™i quy.',3,'COMPLETED','HIGH','Thiáº¿t káº¿ wireframe cá»•ng tá»± phá»¥c vá»¥','2026-07-06 05:41:01.195885');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (18,6,'2025-12-15 08:00:00.000000','NhÃ¢n viÃªn xem phiáº¿u lÆ°Æ¡ng, lá»‹ch sá»­ 12 thÃ¡ng gáº§n nháº¥t, so sÃ¡nh thÃ¡ng trÆ°á»›c. YÃªu cáº§u JWT employee scope.',3,'IN_PROGRESS','HIGH','XÃ¢y dá»±ng trang xem phiáº¿u lÆ°Æ¡ng cÃ¡ nhÃ¢n','2026-07-06 05:41:01.195885');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (19,15,'2026-01-05 08:00:00.000000','Form yÃªu cáº§u nghá»‰ phÃ©p: ngÃ y nghá»‰, loáº¡i nghá»‰ (phÃ©p, á»‘m, khÃ´ng lÆ°Æ¡ng), lÃ½ do, ngÆ°á»i thay tháº¿. ThÃ´ng bÃ¡o quáº£n lÃ½ phÃª duyá»‡t.',3,'OPEN','MEDIUM','Chá»©c nÄƒng Ä‘áº·t lá»‹ch nghá»‰ phÃ©p online','2026-07-06 05:41:01.195885');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (20,15,'2026-01-10 08:00:00.000000','NhÃ¢n viÃªn tá»± cáº­p nháº­t sá»‘ Ä‘iá»‡n thoáº¡i, Ä‘á»‹a chá»‰, CCCD, ngÆ°á»i liÃªn há»‡ kháº©n cáº¥p. HR phÃª duyá»‡t thay Ä‘á»•i thÃ´ng tin quan trá»ng.',3,'OPEN','LOW','Trang há»“ sÆ¡ cÃ¡ nhÃ¢n (tá»± cáº­p nháº­t)','2026-07-06 05:41:01.195885');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (21,3,'2026-01-20 08:00:00.000000','Káº¿t ná»‘i portal vá»›i auth-service qua OAuth 2.0 Authorization Code Flow. Há»— trá»£ Google Workspace SSO cho ná»™i bá»™ ECC.',3,'OPEN','HIGH','TÃ­ch há»£p Single Sign-On (SSO)','2026-07-06 05:41:01.195885');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (22,6,'2026-01-25 08:00:00.000000','Äáº£m báº£o toÃ n bá»™ portal hiá»ƒn thá»‹ tá»‘t trÃªn mobile (320px-768px). Test trÃªn iOS Safari, Android Chrome. Lighthouse â‰¥90.',3,'OPEN','MEDIUM','Responsive mobile layout cho portal','2026-07-06 05:41:01.195885');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (23,9,'2026-01-15 08:00:00.000000','Chá»n tech stack: React Native + Expo. Thiáº¿t káº¿ navigation, state management (Zustand), API client, push notification.',4,'COMPLETED','HIGH','Thiáº¿t káº¿ kiáº¿n trÃºc Mobile App (React Native)','2026-07-06 05:41:01.195885');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (24,15,'2026-01-20 08:00:00.000000','Login screen â†’ nháº­p OTP â†’ lÆ°u JWT token báº£o máº­t (Keychain iOS / Keystore Android). Há»— trá»£ biometric (Face ID, fingerprint).',4,'COMPLETED','URGENT','MÃ n hÃ¬nh Ä‘Äƒng nháº­p & xÃ¡c thá»±c 2FA','2026-07-06 05:41:01.195885');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (25,21,'2026-02-01 08:00:00.000000','Home screen hiá»ƒn thá»‹ task Ä‘Æ°á»£c giao, deadline sáº¯p Ä‘áº¿n, tiáº¿n Ä‘á»™ dá»± Ã¡n, hoáº¡t Ä‘á»™ng gáº§n Ä‘Ã¢y. Pull-to-refresh, skeleton loading.',4,'IN_PROGRESS','HIGH','Dashboard tá»•ng quan dá»± Ã¡n & task','2026-07-06 05:41:01.195885');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (26,23,'2026-02-15 08:00:00.000000','Form táº¡o/sá»­a task: title, description, priority, assignee, deadline, project. Validate form, gá»i API task-service.',4,'IN_PROGRESS','HIGH','MÃ n hÃ¬nh quáº£n lÃ½ task (create/update)','2026-07-06 05:41:01.195885');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (27,21,'2026-03-01 08:00:00.000000','TÃ­ch há»£p Firebase FCM: push khi Ä‘Æ°á»£c giao task, task deadline hÃ´m nay, task Ä‘Æ°á»£c duyá»‡t. Quáº£n lÃ½ subscription theo user.',4,'OPEN','HIGH','Push notification khi task thay Ä‘á»•i','2026-07-06 05:41:01.195885');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (28,23,'2026-03-15 08:00:00.000000','Cache task vÃ  project data offline (SQLite). Sync tá»± Ä‘á»™ng khi cÃ³ máº¡ng, conflict resolution cho thay Ä‘á»•i offline.',4,'OPEN','MEDIUM','Offline mode & data sync','2026-07-06 05:41:01.195885');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (29,16,'2026-04-01 08:00:00.000000','Test Detox E2E trÃªn iPhone 14 vÃ  Samsung Galaxy S23. Coverage: Ä‘Äƒng nháº­p, xem task, cáº­p nháº­t tráº¡ng thÃ¡i, push notification.',4,'OPEN','HIGH','Testing E2E trÃªn thiáº¿t bá»‹ tháº­t','2026-07-06 05:41:01.195885');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (30,9,'2026-05-01 08:00:00.000000','Chuáº©n bá»‹ metadata, screenshot, privacy policy. Submit iOS/Android build cho review. Giáº£i quyáº¿t feedback tá»« Apple/Google.',4,'OPEN','MEDIUM','App Store & Play Store submission','2026-07-06 05:41:01.195885');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (31,19,'2025-08-01 08:00:00.000000','Workshop vá»›i team kinh doanh: xÃ¡c Ä‘á»‹nh data fields cáº§n Ä‘á»“ng bá»™, táº§n suáº¥t sync, xá»­ lÃ½ conflict, mapping schema ECC â†” Salesforce.',5,'COMPLETED','HIGH','PhÃ¢n tÃ­ch yÃªu cáº§u tÃ­ch há»£p CRM','2026-07-06 05:41:01.195885');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (32,14,'2025-09-01 08:00:00.000000','Apache Kafka pipeline: ECC HR â†’ Salesforce Contact sync. Xá»­ lÃ½ dedup, error retry, dead-letter queue.',5,'COMPLETED','URGENT','XÃ¢y dá»±ng ETL pipeline Salesforce â†” MySQL','2026-07-06 05:41:01.195885');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (33,6,'2025-09-15 08:00:00.000000','Endpoint nháº­n Salesforce outbound message khi deal tháº¯ng/thua. Cáº­p nháº­t HR assignments tá»± Ä‘á»™ng.',5,'COMPLETED','HIGH','API webhook nháº­n update tá»« Salesforce','2026-07-06 05:41:01.195885');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (34,22,'2025-10-01 08:00:00.000000','Trang admin xem tráº¡ng thÃ¡i Ä‘á»“ng bá»™: records synced, errors, lag time, queue depth. Alert khi sync bá»‹ lá»—i >5 phÃºt.',5,'COMPLETED','MEDIUM','Dashboard Ä‘á»“ng bá»™ CRM','2026-07-06 05:41:01.195885');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (35,7,'2025-11-01 08:00:00.000000','Test toÃ n bá»™ luá»“ng: táº¡o lead Salesforce â†’ sync HR â†’ assign employee â†’ notify. UAT vá»›i team kinh doanh.',5,'COMPLETED','HIGH','Kiá»ƒm thá»­ tÃ­ch há»£p end-to-end','2026-07-06 05:41:01.195885');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (36,19,'2026-01-15 08:00:00.000000','Deploy production, monitoring 2 tuáº§n, viáº¿t SOP váº­n hÃ nh cho IT Ops, training team kinh doanh sá»­ dá»¥ng dashboard.',5,'COMPLETED','MEDIUM','Go-live & handover tÃ i liá»‡u','2026-07-06 05:41:01.195885');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (37,26,'2025-06-01 08:00:00.000000','PhÃ¢n tÃ­ch workload, chá»n AWS region ap-southeast-1, thiáº¿t káº¿ VPC, subnet, security group, IAM roles theo Well-Architected.',6,'COMPLETED','HIGH','Láº­p káº¿ hoáº¡ch di chuyá»ƒn cloud (Cloud Strategy)','2026-07-06 05:41:01.195885');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (38,11,'2025-07-01 08:00:00.000000','Provision EKS 1.29 vá»›i node group auto-scaling (t3.medium). Config kubectl, Helm, ArgoCD GitOps, Horizontal Pod Autoscaler.',6,'COMPLETED','URGENT','Setup Kubernetes cluster (EKS)','2026-07-06 05:41:01.195885');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (39,17,'2025-08-01 08:00:00.000000','Migrate MySQL â†’ Aurora MySQL 8.0, PostgreSQL â†’ Aurora PostgreSQL 15. Zero-downtime migration dÃ¹ng AWS DMS vá»›i CDC.',6,'COMPLETED','URGENT','Di chuyá»ƒn database lÃªn RDS Aurora','2026-07-06 05:41:01.195885');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (40,5,'2025-09-01 08:00:00.000000','Pipeline build Docker image â†’ push ECR â†’ deploy ArgoCD. Blue-green deployment, canary release, rollback tá»± Ä‘á»™ng khi lá»—i.',6,'COMPLETED','HIGH','Setup CI/CD pipeline (GitHub Actions â†’ ECR â†’ EKS)','2026-07-06 05:41:01.195885');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (41,11,'2025-10-01 08:00:00.000000','Prometheus + Grafana trÃªn cluster. Alert PagerDuty khi CPU>80%, memory>90%, error rate>1%, latency p99>500ms.',6,'COMPLETED','HIGH','Cáº¥u hÃ¬nh monitoring & alerting','2026-07-06 05:41:01.195885');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (42,17,'2025-11-01 08:00:00.000000','Load test 10,000 req/s báº±ng k6. DR drill: táº¯t az-1, verify traffic failover sang az-2. RTO<15 phÃºt, RPO<5 phÃºt.',6,'COMPLETED','URGENT','Kiá»ƒm thá»­ táº£i & disaster recovery','2026-07-06 05:41:01.195885');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (43,25,'2026-03-01 08:00:00.000000','Star schema cho HR analytics: dim_employee, dim_department, fact_payroll, fact_attendance, fact_project_hours. DÃ¹ng dbt.',7,'COMPLETED','HIGH','Thiáº¿t káº¿ Data Warehouse schema','2026-07-06 05:41:01.195885');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (44,14,'2026-03-15 08:00:00.000000','Apache Airflow DAG cháº¡y má»—i Ä‘Ãªm 2h: extract tá»« MySQL/PostgreSQL, transform dbt, load Redshift. Retry 3 láº§n, alert Slack.',7,'IN_PROGRESS','HIGH','XÃ¢y dá»±ng ETL pipeline tá»« OLTP sang DWH','2026-07-06 05:41:01.195885');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (45,25,'2026-04-01 08:00:00.000000','Board: tá»•ng nhÃ¢n viÃªn, tá»· lá»‡ nghá»‰ viá»‡c, phÃ¢n bá»• theo phÃ²ng ban, biá»ƒu Ä‘á»“ tuyá»ƒn dá»¥ng theo thÃ¡ng. Drill-down theo chi nhÃ¡nh.',7,'IN_PROGRESS','HIGH','Dashboard nhÃ¢n sá»± tá»•ng quan (Grafana)','2026-07-06 05:41:01.195885');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (46,11,'2026-04-15 08:00:00.000000','Metabase report: tá»•ng quá»¹ lÆ°Æ¡ng, chi phÃ­ BHXH/BHYT, phÃ¢n tÃ­ch lÆ°Æ¡ng theo level/department, so sÃ¡nh YoY.',7,'OPEN','MEDIUM','Dashboard lÆ°Æ¡ng & chi phÃ­ nhÃ¢n sá»±','2026-07-06 05:41:01.195885');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (47,22,'2026-05-01 08:00:00.000000','Sync project_db vÃ  task_db vÃ o DWH: fact_task (tráº¡ng thÃ¡i, thá»i gian hoÃ n thÃ nh), fact_project_progress theo sprint.',7,'OPEN','MEDIUM','TÃ­ch há»£p dá»¯ liá»‡u project & task vÃ o DWH','2026-07-06 05:41:01.195885');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (48,25,'2026-05-15 08:00:00.000000','Row-level security trong Grafana/Metabase: HR_MANAGER xem táº¥t cáº£, DEPARTMENT_HEAD xem phÃ²ng mÃ¬nh, EMPLOYEE xem báº£n thÃ¢n.',7,'OPEN','LOW','PhÃ¢n quyá»n truy cáº­p bÃ¡o cÃ¡o theo role','2026-07-06 05:41:01.195885');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (49,27,'2026-06-01 09:00:00.000000','Tao checklist chuan cho nhan su moi: tai khoan, thiet bi, quyen truy cap va phan cong nhom.',9,'OPEN','HIGH','Soan quy trinh onboarding noi bo','2026-07-05 08:18:04.282464');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (50,2,'2026-06-02 09:00:00.000000','Thiet ke form tap trung cho yeu cau HR, IT va hanh chinh; bo sung trang thai xu ly.',9,'IN_PROGRESS','HIGH','Chuan hoa luong yeu cau noi bo','2026-07-05 08:18:04.282464');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (51,10,'2026-06-02 09:00:00.000000','Doi chieu laptop, the, may in va tai san van phong theo chi nhanh.',9,'OPEN','MEDIUM','Kiem ke tai san cap nhat','2026-07-05 08:18:04.282464');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (52,18,'2026-06-03 09:00:00.000000','Kiem tra thong tin phuc loi va khoan ho tro de san sang cho ky payroll tiep theo.',9,'OPEN','HIGH','Dong bo du lieu chuyen khoan phuc loi','2026-07-05 08:18:04.282464');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (53,20,'2026-06-03 09:00:00.000000','Tao dashboard don gian cho so luong request moi, dang xu ly va da dong.',9,'OPEN','MEDIUM','Dashboard theo doi request noi bo','2026-07-05 08:18:04.282464');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (54,12,'2026-06-03 09:00:00.000000','Dinh nghia luong hop hang tuan va thong bao nhac viec cho truong nhom.',9,'COMPLETED','LOW','Lich hop nhom va nhac viec','2026-07-05 08:18:04.282464');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (55,24,'2026-06-03 09:00:00.000000','Bo sung bai viet FAQ, quy trinh tiep nhan ticket va mau tra loi nhanh.',10,'IN_PROGRESS','HIGH','Xay dung knowledge base cho support','2026-07-05 08:18:04.282464');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (56,6,'2026-06-04 09:00:00.000000','Hien thi ticket dang mo, SLA vi pham va phan bo theo agent.',10,'IN_PROGRESS','HIGH','Thiet ke giao dien support dashboard','2026-07-05 08:18:04.282464');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (57,7,'2026-06-04 09:00:00.000000','Kiem thu ky luong tat ca workflow ticket: tao, cap nhat, dong va reopen.',10,'OPEN','HIGH','Test regression support flow','2026-07-05 08:18:04.282464');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (58,15,'2026-06-05 09:00:00.000000','Bao dong va chuyen cap khi ticket qua han xu ly.',10,'OPEN','HIGH','Automation SLA escalation','2026-07-05 08:18:04.282464');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (59,21,'2026-06-05 09:00:00.000000','Xay dung API lay danh sach case va cap nhat trang thai xu ly.',10,'IN_PROGRESS','HIGH','Backend API cho case support','2026-07-05 08:18:04.282464');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (60,23,'2026-06-06 09:00:00.000000','Huong dan quy trinh support, cach phan loai ticket va quy tac ung xu.',10,'OPEN','MEDIUM','Onboarding va shadowing cho member moi','2026-07-05 08:18:04.282464');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (61,28,'2026-06-06 09:00:00.000000','Tong hop diem hai long khach hang va xep hang agent.',10,'OPEN','LOW','Bao cao CSAT theo thang','2026-07-05 08:18:04.282464');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (62,11,'2026-06-05 09:00:00.000000','Doi secrets dinh ky va ghi log cac su kien thay doi.',11,'IN_PROGRESS','URGENT','Tu dong hoa xoay secrets','2026-07-05 08:18:04.282464');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (63,16,'2026-06-06 09:00:00.000000','Kiem tra secret expose, scan image va quyen truy cap runner.',11,'OPEN','HIGH','Review bao mat CI pipeline','2026-07-05 08:18:04.282464');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (64,17,'2026-06-06 09:00:00.000000','Them audit trace cho thao tac quan trong va trich xuat forensics.',11,'OPEN','HIGH','Audit log cho he thong cloud','2026-07-05 08:18:04.282464');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (65,22,'2026-06-07 09:00:00.000000','Doi chieu role, quyen va nhom de phat hien quyen thua.',11,'OPEN','MEDIUM','Ma tran quyen truy cap','2026-07-05 08:18:04.282464');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (66,25,'2026-06-07 09:00:00.000000','Chuan hoa cac buoc xu ly su co va danh sach lien lac khi khan cap.',11,'OPEN','HIGH','Incident response playbook','2026-07-05 08:18:04.282464');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (67,26,'2026-06-07 09:00:00.000000','Bat quet dependency va bao cao loi bao mat hang ngay.',11,'COMPLETED','MEDIUM','Dependency and SAST scan policy','2026-07-05 08:18:04.282464');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (68,25,'2026-06-07 09:00:00.000000','Dashboard tong hop so lieu nhan su, chi phi va tien do du an.',12,'IN_PROGRESS','HIGH','Executive KPI dashboard','2026-07-05 08:18:04.282464');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (69,14,'2026-06-08 09:00:00.000000','Phan tich ty le nghi viec va xuat so sanh giua cac phong ban.',12,'OPEN','HIGH','Turnover analytics theo phong ban','2026-07-05 08:18:04.282464');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (70,19,'2026-06-08 09:00:00.000000','Tong hop du lieu pipeline kinh doanh va mapping sang nhan su phu trach.',12,'OPEN','MEDIUM','Revenue pipeline overview','2026-07-05 08:18:04.282464');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (71,1,'2026-06-08 09:00:00.000000','Lam sach du lieu KPI de dong bo voi DWH.',12,'OPEN','MEDIUM','Normalize department KPI data','2026-07-05 08:18:04.282464');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (72,3,'2026-06-09 09:00:00.000000','Tong hop so nguoi tren moi du an va canh bao team qua tai.',12,'IN_PROGRESS','HIGH','Project allocation report','2026-07-05 08:18:04.282464');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (73,4,'2026-06-09 09:00:00.000000','Loc cac task qua han va de xuat xu ly nhanh.',12,'OPEN','HIGH','Task aging cleanup','2026-07-05 08:18:04.282464');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (74,5,'2026-06-09 09:00:00.000000','Xuat bao cao sprint de gui ban lanh dao vao cuoi tuan.',12,'OPEN','LOW','Sprint status export','2026-07-05 08:18:04.282464');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (75,8,'2026-06-10 09:00:00.000000','Dong bo cay to chuc va phong ban sang dashboard quan tri.',12,'OPEN','MEDIUM','Org chart sync job','2026-07-05 08:18:04.282464');
INSERT INTO `tasks` (`id`, `assignee_id`, `created_at`, `description`, `project_id`, `status`, `priority`, `title`, `updated_at`) VALUES (76,9,'2026-06-10 09:00:00.000000','Tao ban tom tat thang cho ban lanh dao, gom nhan su, du an va chi phi.',12,'OPEN','HIGH','Monthly leadership summary','2026-07-05 08:18:04.282464');
/*!40000 ALTER TABLE `tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'task_db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-06  5:42:29
